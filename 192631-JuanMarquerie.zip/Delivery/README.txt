Juan S. Marquerie - 192631- juansebastian.marquerie01@estudiant.upf.edu

Los controles son con la cruceta para moverse y saltar, y luego r para reiniciar el juego.
Aunque tenia preparados los clips de audio, pero perdi mucho tiempo intentando arreglar el porblema de audio en linux, asi que se quedo sin sonido.

Enlace del video: https://youtu.be/o_tgjaUyGLw

